namespace EduAIWeb.Models;

public class EducationalExample
{
    public string Name { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public string HoverDescription { get; set; } = string.Empty;
    public string Badge { get; set; } = string.Empty;
}

public class EducationalBlock
{
    public string Id { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string IconClass { get; set; } = string.Empty;
    public string ShortParagraph { get; set; } = string.Empty;
    public string ExternalReferenceUrl { get; set; } = string.Empty;
    public string ExternalReferenceTitle { get; set; } = string.Empty;
    public List<EducationalExample> Examples { get; set; } = new();
}

public class HomeViewModel
{
    public List<EducationalBlock> EducationalBlocks { get; set; } = new();
    public List<AIImage> FeaturedImages { get; set; } = new();
}

