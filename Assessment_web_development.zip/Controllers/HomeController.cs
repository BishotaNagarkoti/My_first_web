using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EduAIWeb.Data;
using EduAIWeb.Models;

namespace EduAIWeb.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<HomeController> _logger;

    public HomeController(ApplicationDbContext context, ILogger<HomeController> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<IActionResult> Index()
    {
        // 3 Sustainability Content Blocks for AI in Sustainability theme
        var educationalBlocks = new List<EducationalBlock>
        {
            new EducationalBlock
            {
                Id = "block-climate",
                Number = "01",
                Category = "ATMOSPHERIC PHYSICS",
                Title = "Climate Prediction",
                IconClass = "fa-solid fa-cloud-bolt",
                ShortParagraph = "High-performance neural networks model complex atmospheric physics, forecast severe weather anomalies, and track global greenhouse gas concentrations with unmatched precision.",
                ExternalReferenceUrl = "https://www.ecmwf.int/",
                ExternalReferenceTitle = "Read more",
                Examples = new List<EducationalExample>
                {
                    new EducationalExample
                    {
                        Name = "GraphCast",
                        Url = "https://deepmind.google/discover/blog/graphcast-ai-model-for-faster-and-more-accurate-global-weather-forecasting/",
                        HoverDescription = "GraphCast is an AI-based weather forecasting system capable of predicting global medium-range weather conditions 10 days in advance within seconds. <br><strong>DeepMind</strong>",
                        Badge = "Google DeepMind"
                    },
                    new EducationalExample
                    {
                        Name = "ClimaX",
                        Url = "https://www.microsoft.com/en-us/research/project/climax/",
                        HoverDescription = "ClimaX is the first foundation model designed for weather and climate projections across diverse variables and temporal scales. <br><strong>Microsoft Research</strong>",
                        Badge = "Microsoft Research"
                    }
                }
            },
            new EducationalBlock
            {
                Id = "block-energy",
                Number = "02",
                Category = "GRID EFFICIENCY & STORAGE",
                Title = "Energy Optimisation",
                IconClass = "fa-solid fa-bolt-lightning",
                ShortParagraph = "Machine learning algorithms dynamically balance fluctuating renewable supplies, forecast peak loads on electrical grids, and reduce thermal data center power consumption.",
                ExternalReferenceUrl = "https://www.iea.org/reports/artificial-intelligence-in-energy",
                ExternalReferenceTitle = "Read more",
                Examples = new List<EducationalExample>
                {
                    new EducationalExample
                    {
                        Name = "DeepMind Cooling",
                        Url = "https://deepmind.google/discover/blog/deepmind-ai-reduces-google-data-centre-cooling-bill-by-40/",
                        HoverDescription = "DeepMind applied reinforcement learning to autonomous cooling in cloud facilities, achieving a consistent 40% reduction in cooling energy. <br><strong>Google Cloud</strong>",
                        Badge = "Google Cloud"
                    },
                    new EducationalExample
                    {
                        Name = "AutoGrid",
                        Url = "https://www.auto-grid.com/",
                        HoverDescription = "AutoGrid utilizes predictive AI to orchestrate distributed energy resources, virtual power plants, and renewable microgrids in real time. <br><strong>Schneider Electric</strong>",
                        Badge = "Schneider Electric"
                    }
                }
            },
            new EducationalBlock
            {
                Id = "block-agriculture",
                Number = "03",
                Category = "PRECISION AGRI-TECH",
                Title = "Smart Agriculture",
                IconClass = "fa-solid fa-seedling",
                ShortParagraph = "Computer vision and predictive IoT sensors optimize water usage, reduce chemical pesticide runoff via precision spraying, and maximize crop yields sustainably.",
                ExternalReferenceUrl = "https://www.fao.org/",
                ExternalReferenceTitle = "Read more",
                Examples = new List<EducationalExample>
                {
                    new EducationalExample
                    {
                        Name = "See & Spray",
                        Url = "https://www.deere.com/en/our-company/news-and-announcements/news-releases/2022/agriculture/see-spray-ultimate/",
                        HoverDescription = "See & Spray uses computer vision and machine learning to target and spray herbicide on weeds only, reducing chemical herbicide use by up to two-thirds. <br><strong>John Deere</strong>",
                        Badge = "John Deere"
                    },
                    new EducationalExample
                    {
                        Name = "FieldView",
                        Url = "https://climate.com/",
                        HoverDescription = "FieldView synthesizes satellite imagery, sensor data, and soil mapping to deliver targeted micro-climate yield insights for farmers. <br><strong>Climate LLC</strong>",
                        Badge = "Climate LLC"
                    }
                }
            }
        };

        List<AIImage> uploadedImages;
        try
        {
            // Page 13: List sorted by number of likes in descending order, from highest to lowest.
            uploadedImages = await _context.AIImages
                .OrderByDescending(i => i.Like)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to load featured AI images for Home index.");
            uploadedImages = new List<AIImage>();
        }

        var viewModel = new HomeViewModel
        {
            EducationalBlocks = educationalBlocks,
            FeaturedImages = uploadedImages
        };

        return View(viewModel);
    }

    public IActionResult Contact()
    {
        return View();
    }

    // Creative Page required by Requirement 4 & Assessment 3: EcoCalculator
    public IActionResult EcoCalculator()
    {
        return View();
    }

    // Backward-compatibility alias for Explore
    public IActionResult Explore()
    {
        return RedirectToAction(nameof(EcoCalculator));
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
