using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EduAIWeb.Data;
using EduAIWeb.Models;

namespace EduAIWeb.Controllers;

public class AIImagesController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IWebHostEnvironment _environment;
    private readonly ILogger<AIImagesController> _logger;

    public AIImagesController(
        ApplicationDbContext context, 
        IWebHostEnvironment environment,
        ILogger<AIImagesController> logger)
    {
        _context = context;
        _environment = environment;
        _logger = logger;
    }

    // GET: /AIImages or /AIImages/Index
    // Visitor: Read-only gallery (no action buttons).
    // Member: Like button (1 per session) + Create link.
    // Admin: Full action buttons (Like, Edit, Delete, Details).
    [AllowAnonymous]
    public async Task<IActionResult> Index()
    {
        try
        {
            // List of AI Images: Sorted in chronological order by UploadDate
            var images = await _context.AIImages
                .OrderBy(i => i.UploadDate)
                .ToListAsync();

            // Session check for single like per login session
            var likedIds = GetLikedImageIdsFromSession();
            ViewBag.LikedIds = likedIds;

            return View(images);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading AI Images index.");
            return View(new List<AIImage>());
        }
    }

    // GET: /AIImages/Details/5
    // Accessible strictly by Admin role
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        try
        {
            var image = await _context.AIImages.FirstOrDefaultAsync(m => m.Id == id);
            if (image == null) return NotFound();

            return View(image);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching details for AI Image {Id}", id);
            return RedirectToAction(nameof(Index));
        }
    }

    // GET: /AIImages/Create
    // Accessible by Member and Admin
    [Authorize(Roles = "Member,Admin")]
    public IActionResult Create()
    {
        var model = new AIImage
        {
            UploadDate = DateTime.Now,
            Like = 0,
            canIncreaseLike = true
        };
        return View(model);
    }

    // POST: /AIImages/Create
    [HttpPost]
    [Authorize(Roles = "Member,Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(AIImage model, IFormFile? imageFile)
    {
        // Auto-assign read-only rubric attributes
        model.UploadDate = DateTime.Now;
        model.Like = 0;
        model.canIncreaseLike = true;

        if (ModelState.IsValid)
        {
            try
            {
                if (imageFile != null && imageFile.Length > 0)
                {
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var safeFileName = Path.GetFileName(imageFile.FileName);
                    var uniqueFileName = $"{Guid.NewGuid():N[..8]}_{safeFileName}";
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await imageFile.CopyToAsync(stream);
                    }

                    model.Filename = uniqueFileName;
                }
                else
                {
                    model.Filename = "solar-drone.svg";
                }

                _context.Add(model);
                await _context.SaveChangesAsync();

                // Redirect to the created item using the anchor
                return Redirect($"/AIImages/Index#img-block-{model.Id}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating new AI Image record.");
                ModelState.AddModelError(string.Empty, "Unable to save image due to a system error. Please try again.");
            }
        }

        return View(model);
    }

    // GET: /AIImages/Edit/5
    // Accessible strictly by Admin role
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();

        try
        {
            var image = await _context.AIImages.FindAsync(id);
            if (image == null) return NotFound();

            return View(image);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving AI Image {Id} for editing.", id);
            return RedirectToAction(nameof(Index));
        }
    }

    // POST: /AIImages/Edit/5
    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, AIImage model, IFormFile? imageFile)
    {
        if (id != model.Id) return NotFound();

        try
        {
            var existing = await _context.AIImages.FindAsync(id);
            if (existing == null) return NotFound();

            if (ModelState.IsValid)
            {
                existing.Prompt = model.Prompt;
                existing.ImageGenerator = model.ImageGenerator;

                if (imageFile != null && imageFile.Length > 0)
                {
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var safeFileName = Path.GetFileName(imageFile.FileName);
                    var uniqueFileName = $"{Guid.NewGuid():N[..8]}_{safeFileName}";
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await imageFile.CopyToAsync(stream);
                    }

                    existing.Filename = uniqueFileName;
                }

                await _context.SaveChangesAsync();
                return Redirect($"/AIImages/Index#img-block-{existing.Id}");
            }
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!AIImageExists(model.Id)) return NotFound();
            _logger.LogWarning("Concurrency collision editing AI Image {Id}", model.Id);
            ModelState.AddModelError(string.Empty, "The record was modified by another user. Please reload.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error editing AI Image {Id}", model.Id);
            ModelState.AddModelError(string.Empty, "A database error occurred while updating the record.");
        }

        return View(model);
    }

    // GET: /AIImages/Delete/5
    // Accessible strictly by Admin role
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();

        try
        {
            var image = await _context.AIImages.FirstOrDefaultAsync(m => m.Id == id);
            if (image == null) return NotFound();

            return View(image);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving AI Image {Id} for delete confirmation.", id);
            return RedirectToAction(nameof(Index));
        }
    }

    // POST: /AIImages/Delete/5
    [HttpPost, ActionName("Delete")]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        try
        {
            var image = await _context.AIImages.FindAsync(id);
            if (image != null)
            {
                _context.AIImages.Remove(image);
                await _context.SaveChangesAsync();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting AI Image {Id}", id);
        }

        return RedirectToAction(nameof(Index));
    }

    // POST: /AIImages/Like/5
    // Accessible by Member and Admin
    [HttpPost]
    [Authorize(Roles = "Member,Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Like(int id)
    {
        try
        {
            var image = await _context.AIImages.FindAsync(id);
            if (image == null) return NotFound();

            var likedIds = GetLikedImageIdsFromSession();
            if (!likedIds.Contains(id))
            {
                image.Like += 1;
                likedIds.Add(id);
                SaveLikedImageIdsToSession(likedIds);
                await _context.SaveChangesAsync();
            }

            // Page 13: Scrolls up/down to bring the clicked Like block to the top
            return Redirect($"/AIImages/Index#img-block-{id}");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing like for AI Image {Id}", id);
            return Redirect($"/AIImages/Index#img-block-{id}");
        }
    }

    private bool AIImageExists(int id)
    {
        try
        {
            return _context.AIImages.Any(e => e.Id == id);
        }
        catch
        {
            return false;
        }
    }

    private HashSet<int> GetLikedImageIdsFromSession()
    {
        try
        {
            var sessionString = HttpContext.Session.GetString("LikedAIImageIds");
            if (string.IsNullOrEmpty(sessionString))
            {
                return new HashSet<int>();
            }
            return sessionString.Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToHashSet();
        }
        catch
        {
            return new HashSet<int>();
        }
    }

    private void SaveLikedImageIdsToSession(HashSet<int> likedIds)
    {
        try
        {
            HttpContext.Session.SetString("LikedAIImageIds", string.Join(",", likedIds));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to persist liked image IDs to session.");
        }
    }
}
