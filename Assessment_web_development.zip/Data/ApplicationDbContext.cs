using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using EduAIWeb.Models;

namespace EduAIWeb.Data;

public class ApplicationDbContext : IdentityDbContext<IdentityUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<AIImage> AIImages => Set<AIImage>();
    public DbSet<ContactMessage> ContactMessages => Set<ContactMessage>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Seed 4 realistic sustainability AIImage items matching Model on Page 22
        modelBuilder.Entity<AIImage>().HasData(
            new AIImage
            {
                Id = 1,
                Prompt = "Autonomous solar drone monitoring vineyard moisture and soil health using multispectral computer vision.",
                ImageGenerator = "Gemini",
                UploadDate = new DateTime(2026, 9, 15, 10, 30, 0),
                Filename = "solar-drone.jpg",
                Like = 142,
                canIncreaseLike = true
            },
            new AIImage
            {
                Id = 2,
                Prompt = "Offshore wind turbine neural network predictive maintenance and blade structural telemetry.",
                ImageGenerator = "Claude",
                UploadDate = new DateTime(2026, 9, 18, 14, 15, 0),
                Filename = "wind-turbine.jpg",
                Like = 98,
                canIncreaseLike = true
            },
            new AIImage
            {
                Id = 3,
                Prompt = "Satellite infrared deforestation analysis and canopy biomass carbon sequestration tracking.",
                ImageGenerator = "ChatGPT",
                UploadDate = new DateTime(2026, 9, 22, 9, 45, 0),
                Filename = "satellite-forest.jpg",
                Like = 67,
                canIncreaseLike = true
            },
            new AIImage
            {
                Id = 4,
                Prompt = "High-density smart grid power distribution node with AI-driven battery storage load-balancing.",
                ImageGenerator = "ChatGPT",
                UploadDate = new DateTime(2026, 9, 28, 16, 20, 0),
                Filename = "smart-grid.jpg",
                Like = 185,
                canIncreaseLike = true
            }
        );
    }
}
