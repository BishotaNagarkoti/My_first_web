using Microsoft.AspNetCore.Identity;
using EduAIWeb.Models;

namespace EduAIWeb.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(
        ApplicationDbContext context,
        UserManager<IdentityUser> userManager,
        RoleManager<IdentityRole> roleManager)
    {
        // Automatically create database and apply EF Core model seeds
        context.Database.EnsureCreated();

        // 1. Seed Roles
        string[] roles = { "Admin", "Member" };
        foreach (var role in roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                await roleManager.CreateAsync(new IdentityRole(role));
            }
        }

        // 2. Seed Admin User: admin@asp.net
        var adminEmail = "admin@asp.net";
        var adminUser = await userManager.FindByEmailAsync(adminEmail);
        if (adminUser == null)
        {
            adminUser = new IdentityUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                EmailConfirmed = true
            };
            var result = await userManager.CreateAsync(adminUser, "Admin@123");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }
        }

        // 3. Seed Demo Member User: member@asp.net
        var memberEmail = "member@asp.net";
        var memberUser = await userManager.FindByEmailAsync(memberEmail);
        if (memberUser == null)
        {
            memberUser = new IdentityUser
            {
                UserName = memberEmail,
                Email = memberEmail,
                EmailConfirmed = true
            };
            var result = await userManager.CreateAsync(memberUser, "Member@123");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(memberUser, "Member");
            }
        }

        // 4. Seed / Update Sustainability AIImages if empty or containing old education seeds
        var existingImages = context.AIImages.ToList();
        bool needsReseed = !existingImages.Any() || existingImages.Any(i => i.Prompt.Contains("educational") || i.Prompt.Contains("classroom") || i.Filename.Contains("dashboard"));
        if (needsReseed)
        {
            if (existingImages.Any())
            {
                context.AIImages.RemoveRange(existingImages);
                context.SaveChanges();
            }

            context.AIImages.AddRange(
                new AIImage
                {
                    Id = 1,
                    Prompt = "Autonomous solar drone monitoring vineyard moisture and soil health using multispectral computer vision.",
                    ImageGenerator = "Gemini",
                    UploadDate = new DateTime(2026, 9, 15, 10, 30, 0),
                    Filename = "solar-drone.jpg",
                    Like = 142,
                    canIncreaseLike = true
                },
                new AIImage
                {
                    Id = 2,
                    Prompt = "Offshore wind turbine neural network predictive maintenance and blade structural telemetry.",
                    ImageGenerator = "Claude",
                    UploadDate = new DateTime(2026, 9, 18, 14, 15, 0),
                    Filename = "wind-turbine.jpg",
                    Like = 98,
                    canIncreaseLike = true
                },
                new AIImage
                {
                    Id = 3,
                    Prompt = "Satellite infrared deforestation analysis and canopy biomass carbon sequestration tracking.",
                    ImageGenerator = "ChatGPT",
                    UploadDate = new DateTime(2026, 9, 22, 9, 45, 0),
                    Filename = "satellite-forest.jpg",
                    Like = 67,
                    canIncreaseLike = true
                },
                new AIImage
                {
                    Id = 4,
                    Prompt = "High-density smart grid power distribution node with AI-driven battery storage load-balancing.",
                    ImageGenerator = "ChatGPT",
                    UploadDate = new DateTime(2026, 9, 28, 16, 20, 0),
                    Filename = "smart-grid.jpg",
                    Like = 185,
                    canIncreaseLike = true
                }
            );
            context.SaveChanges();
        }
    }
}
