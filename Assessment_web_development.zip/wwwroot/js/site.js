// ==========================================================================
// External JavaScript (Assessment 3 - Unit 7175)
// Strictly External Script - Zero inline or internal scripts inside .cshtml
// ==========================================================================

document.addEventListener("DOMContentLoaded", function () {
    // ----------------------------------------------------------------------
    // 1. Viewport Visibility Tracking for Educational Blocks (Pages 4–6)
    // Requirement: Each block must appear ONLY when fully in the viewport,
    // and disappear immediately when scrolled out of view.
    // ----------------------------------------------------------------------
    var viewportBlocks = document.querySelectorAll(".viewport-block");

    function checkViewportBlocks() {
        var windowHeight = window.innerHeight || document.documentElement.clientHeight;
        viewportBlocks.forEach(function (block) {
            var rect = block.getBoundingClientRect();
            // Fully within viewport: top is >= 0 and bottom is <= window height
            var isFullyIn = (rect.top >= 0 && rect.bottom <= windowHeight);

            // Responsive fallback if block height exceeds screen height on small viewports
            if (rect.height > windowHeight) {
                isFullyIn = (rect.top <= 0 && rect.bottom >= windowHeight);
            }

            if (isFullyIn) {
                block.classList.add("is-visible");
            } else {
                block.classList.remove("is-visible");
            }
        });
    }

    if ("IntersectionObserver" in window) {
        var observer = new IntersectionObserver(function () {
            checkViewportBlocks();
        }, {
            threshold: [0, 0.2, 0.4, 0.6, 0.8, 1.0]
        });

        viewportBlocks.forEach(function (block) {
            observer.observe(block);
        });
    }

    window.addEventListener("scroll", checkViewportBlocks, { passive: true });
    window.addEventListener("resize", checkViewportBlocks, { passive: true });
    checkViewportBlocks();

    // ----------------------------------------------------------------------
    // 2. Hash Anchor Smooth Scroll (Page 13)
    // Requirement: Bring the block with the clicked Like button or
    // thumbnail to the top of the page.
    // ----------------------------------------------------------------------
    function scrollToHashAnchor() {
        if (window.location.hash) {
            var hash = window.location.hash;
            var targetEl = document.querySelector(hash);

            if (!targetEl) {
                if (hash.indexOf("#img-block-") === 0) {
                    var id1 = hash.replace("#img-block-", "");
                    targetEl = document.getElementById("image-" + id1);
                } else if (hash.indexOf("#image-") === 0) {
                    var id2 = hash.replace("#image-", "");
                    targetEl = document.getElementById("img-block-" + id2);
                }
            }

            if (targetEl) {
                setTimeout(function () {
                    targetEl.scrollIntoView({ behavior: "smooth", block: "start" });
                }, 180);
            }
        }
    }

    scrollToHashAnchor();
    window.addEventListener("hashchange", scrollToHashAnchor);

    // ----------------------------------------------------------------------
    // 3. AI Carbon Offset & Grid Efficiency Calculator (EcoCalculator)
    // ----------------------------------------------------------------------
    var calcForm = document.getElementById("eco-calculator-form");
    if (calcForm) {
        var facilitySelect = document.getElementById("facility-type");
        var kwhInput = document.getElementById("monthly-kwh");
        var btnCalculate = document.getElementById("btn-calculate-eco");
        var btnReset = document.getElementById("btn-reset-eco");

        var resEfficiency = document.getElementById("res-efficiency-pct");
        var resKwhSaved = document.getElementById("res-kwh-saved");
        var resCo2 = document.getElementById("res-co2-abated");
        var resCost = document.getElementById("res-cost-saved");
        var resTrees = document.getElementById("res-trees-equiv");

        function calculateImpact() {
            var kwh = parseFloat(kwhInput.value) || 0;
            if (kwh <= 0) return;

            var selectedOption = facilitySelect.options[facilitySelect.selectedIndex];
            var reductionRatio = parseFloat(selectedOption.getAttribute("data-reduction")) || 0.40;
            var co2Factor = parseFloat(selectedOption.getAttribute("data-co2")) || 0.65; // kg CO2 per kWh

            var kwhSaved = kwh * reductionRatio;
            var co2Tons = (kwhSaved * co2Factor) / 1000.0;
            var costSaved = kwhSaved * 0.28; // $0.28 per kWh AUD average commercial rate
            var treesEquivalent = Math.round(co2Tons * 48); // ~48 trees per metric ton of CO2/yr

            if (resEfficiency) resEfficiency.textContent = (reductionRatio * 100).toFixed(1) + "%";
            if (resKwhSaved) resKwhSaved.textContent = Math.round(kwhSaved).toLocaleString() + " kWh";
            if (resCo2) resCo2.textContent = co2Tons.toFixed(2) + " t";
            if (resCost) resCost.textContent = "$" + Math.round(costSaved).toLocaleString();
            if (resTrees) resTrees.textContent = "Equivalent to planting " + treesEquivalent.toLocaleString() + " urban trees annually";
        }

        if (btnCalculate) btnCalculate.addEventListener("click", calculateImpact);
        if (facilitySelect) facilitySelect.addEventListener("change", calculateImpact);
        if (kwhInput) kwhInput.addEventListener("input", calculateImpact);
        if (btnReset) {
            btnReset.addEventListener("click", function () {
                facilitySelect.selectedIndex = 0;
                kwhInput.value = 50000;
                calculateImpact();
            });
        }

        calculateImpact();
    }

    // ----------------------------------------------------------------------
    // 4. Client-side File Upload Preview (Create / Edit Pages)
    // ----------------------------------------------------------------------
    var fileInput = document.querySelector('input[type="file"][name="imageFile"]');
    var previewImg = document.getElementById("previewImage");
    if (fileInput && previewImg) {
        fileInput.addEventListener("change", function () {
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    previewImg.src = e.target.result;
                };
                reader.readAsDataURL(fileInput.files[0]);
            }
        });
    }
});
